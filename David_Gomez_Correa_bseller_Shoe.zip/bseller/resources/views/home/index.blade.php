@extends('layouts.app')
@section('title', 'Home Page - BSeller')
@section('content')
<h1>Welcome to BSeller!</h1>
<p>This is a reseller of unique shoes!</p>
@endsection