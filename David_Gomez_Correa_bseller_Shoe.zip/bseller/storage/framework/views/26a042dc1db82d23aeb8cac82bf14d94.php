
<?php $__env->startSection('title', 'Home Page - BSeller'); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
  <div class="alert alert-success">                
    <?php echo e(session('status')); ?>

  </div>        
<?php endif; ?>
<h1>Shoes</h1>
<p>Here you can find all the current available Shoes!</p>
<div class="botton-position">
    <a target="_blank" class="fcc-btn" href="<?php echo e(route('shoe.list')); ?>">List of the available shoes</a>
    <a target="_blank" class="fcc-btn" href="<?php echo e(route('shoe.create')); ?>">Add a new shoe</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Eafit\bseller\bseller\resources\views/shoe/index.blade.php ENDPATH**/ ?>