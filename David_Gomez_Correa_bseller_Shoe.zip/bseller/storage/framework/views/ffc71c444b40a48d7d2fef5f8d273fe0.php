
<?php $__env->startSection('title', $viewData["title"]); ?>
<?php $__env->startSection('subtitle', $viewData["subtitle"]); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
  <div class="alert alert-success">                
    <?php echo e(session('status')); ?>

  </div>        
<?php endif; ?>
<section class="product-section">
  <div class="card-estilo-0">
    <div class="img-container">
      <img src="<?php echo e(asset($viewData["product"]["image"])); ?>">
    </div>
    <p class="card-title">
      Model: <?php echo e($viewData["product"]["model"]); ?>

    </p>
    <p class="card-title">
      Brand: <?php echo e($viewData["product"]["brand"]); ?>

    </p>
    <p class="card-title">
      Size: <?php echo e($viewData["product"]["size"]); ?>

    </p>
    <p class="card-text">
      Price: <?php echo e($viewData["product"]["price"]); ?>

    </p>
    <form method="POST" action="<?php echo e(route('shoe.delete', ['id' => $viewData["product"]["id"]])); ?>">                        
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button type="submit" class="btn btn-danger">Delete</button>                    
    </form>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Eafit\bseller\bseller\resources\views/shoe/show.blade.php ENDPATH**/ ?>